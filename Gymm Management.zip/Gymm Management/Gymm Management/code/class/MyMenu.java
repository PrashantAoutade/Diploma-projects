
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class MyMenu extends JFrame implements ActionListener
{
 JButton b1,b2,b3,b4,b5,b6,b7,b8,b9,b10;
 JLabel l1,lbl,l2;
 public MyMenu()
 {
  super("Gymm Mgnt.System");
  b1=new JButton("NEW CUSTOMER");
  b2=new JButton("DELETE CUSTOMER");
  b3=new JButton("CUSTOMER'S INFORMATION");
  b4=new JButton("UPDATE CUSTOMER");
  b5=new JButton("EXIT");
  b6=new JButton("TOOL INFORMATON");
  b7=new JButton("About");
  b8=new JButton("COACH INFORMATION");
  b9=new JButton("INSTRUCTIONS");
  b10=new JButton("REPORT");
  l1=new JLabel();
  lbl=new JLabel();

  Font f=new Font("Times new Roman",Font.BOLD,40);
  l1.setFont(new Font("Times new Roman",Font.BOLD,50));
  l1.setForeground(Color.red);
  l1.setText("  Fitness  Point");

  b1.setBounds(30,100,250,30);             b1.setForeground(new Color(175,50,175));  
  b2.setBounds(70,145,250,30);             b2.setForeground(new Color(175,50,175));
  b3.setBounds(110,185,250,30);           b3.setForeground(new Color(175,50,175));
  b4.setBounds(150,225,250,30);           b4.setForeground(new Color(175,50,175));
  b6.setBounds(190,265,250,30);           b6.setForeground(new Color(175,50,175));
  b5.setBounds(500,485,130,30);           b5.setForeground(new Color(175,50,175));
  b7.setBounds(500,435,130,30);           b7.setForeground(new Color(175,50,175));
  b8.setBounds(230,310,250,30);           b8.setForeground(new Color(175,50,175));
  b9.setBounds(230,355,250,30);           b9.setForeground(new Color(175,50,175));

  b10.setBounds(230,400,250,30);           b10.setForeground(new Color(175,50,175));
  l1.setBounds(200,20,450,50);
  lbl.setBounds(150,200,50,50);


   l2 = new JLabel("", new ImageIcon("C:/sunil/Gymm Management/Image/happy1.png"), JLabel.CENTER);
   l2.setBounds(435,120,400,300);
   add(l2);





   
  b1.addActionListener(this);
  b2.addActionListener(this);
  b3.addActionListener(this);
  b4.addActionListener(this);
  b6.addActionListener(this);
  b5.addActionListener(this);
  b7.addActionListener(this);
  b8.addActionListener(this);
  b9.addActionListener(this);
  b10.addActionListener(this); 
  Container c1=getContentPane();
  c1.setLayout(null);

  c1.add(b1);
  c1.add(b2);
  c1.add(b3);
  c1.add(b4);
  c1.add(b6);
  c1.add(b5);
  c1.add(b7);
  c1.add(b8);
  c1.add(b9);
  c1.add(b10);
  c1.add(lbl); 
  c1.add(l1);
  
 
  setSize(800,600);
  setVisible(true);
  this.setResizable(false);
  this.setLocation(300,50);

  getContentPane().setBackground(Color.white);

  setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
 }
 public static void main(String args[])
 {
  new MyMenu();
 }
 public void actionPerformed(ActionEvent a1)
 {
    if(a1.getSource()==b9)
  {
new int11();
   this.setVisible(false);
  }


  if(a1.getSource()==b8)
  {
   new Coach();
   this.setVisible(false);
  }


   if(a1.getSource()==b7)
  {
   new About();
   this.setVisible(false);
  }
 


  if(a1.getSource()==b1)
  {
   new AddCust();
   this.setVisible(false);
  }
  if(a1.getSource()==b2)
  {
   new DeleteCust();
   this.setVisible(false);
  }
  if(a1.getSource()==b3)
  {
   new Report();
   this.setVisible(false);              
  }
  if(a1.getSource()==b4)
  {
   new EditCust();
   this.setVisible(false);
  }
  if(a1.getSource()==b10)
  {
   new GymReport();
   this.setVisible(false);
  }
  
  if(a1.getSource()==b6)
  {
   new ToolInfo();
   this.setVisible(false);
  }
  if(a1.getSource()==b5)
  {
   try
   {
    String s1=a1.getActionCommand();
    if(s1.equals("EXIT"))
    {
     int res=JOptionPane.showConfirmDialog(null,"Do you want to exit?","EXIT",JOptionPane.YES_NO_OPTION);
     if(res==JOptionPane.YES_OPTION)
     {
      System.exit(0);
     }
    }
   }
   catch(Exception e) 
   {
    System.out.println("ERROR:"+e);
   }
  }
 }
}


